libastar 0 libastar (>> 0.9), libastar (<< 0.9-99)
